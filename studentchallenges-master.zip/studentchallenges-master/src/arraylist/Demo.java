package arraylist;

import java.util.ArrayList;

public class Demo {

	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<>();
		
		list.add(10);
		list.add(105);
		list.add(10);
		System.out.println(list);
	}
}
