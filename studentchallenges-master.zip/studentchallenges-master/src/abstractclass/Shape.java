package abstractclass;

abstract class Shape {

	abstract public double perimeter();
	abstract public double area();
	
}
