package Interface;

public interface Member {
	void callback();
}
