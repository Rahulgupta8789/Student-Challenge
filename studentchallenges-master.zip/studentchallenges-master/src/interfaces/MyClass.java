package interfaces;

public class MyClass implements Test{

	public void meth1() {
		System.out.println("meth1 from MyClass");
	}
	public void meth2() {
		System.out.println("meth2 from MyClass");
	}
	public void meth3() {
		System.out.println("meth3 from MyClass");
	}
}
