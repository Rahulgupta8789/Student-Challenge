package interfaces;

interface Test {
	void meth1();
	void meth2();
}
