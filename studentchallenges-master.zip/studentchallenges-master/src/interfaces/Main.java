package interfaces;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test t=new MyClass();
//		MyClass t=new MyClass();
		t.meth1();
		t.meth2();
		//t.meth3();
	}

}
