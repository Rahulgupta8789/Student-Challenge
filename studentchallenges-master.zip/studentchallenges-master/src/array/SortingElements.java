package array;

public class SortingElements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String arr[]={"java","python","pascal","smalltalk","ada","basic"};
        
        java.util.Arrays.sort(arr);
        
        for(String x:arr)
            System.out.println(x);

	}

}
